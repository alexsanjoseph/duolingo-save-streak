
def main():
    import duolingo

    try:
        lingo = duolingo.Duolingo('alexjoseph398895')
    except ValueError:
        raise UserWarning("Username Invalid")
        exit()

    print("Trying to Buy Streak Freeze")
    lingo.get_streak_info()
